public class QueueException extends Exception
{
  public QueueException(String s)
  {
    super(s);
  }
}