public class Stack<T>
{
  private LL<T> theStack;

  public Stack()
  {
    theStack = new LL<T>();
  }

  public boolean isEmpty()
  {
    return theStack.isEmpty();
  }

  public boolean isFull()
  {
    return false;
  }

  public void push(T value) throws LLExe
  {
    theStack.insertAtHead(value);
  }
    
  public T pop()
  {
    return theStack.removeAtHead();
  }

  public static void main(String args[])
  {
    Stack<Double> A = new Stack<Double>();

    A.push(2.1);
 
  }
 
}