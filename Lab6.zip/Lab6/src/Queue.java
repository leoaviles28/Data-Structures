public class Queue<T>
{
  private LL<T> theQueue;

  public Queue()
  {
    theQueue = new LL<T>();
  }

  public boolean isEmpty()
  {
    return theQueue.isEmpty();
  }

  public boolean isFull()
  {
    return false;
  }

  public void enqueue(T value) throws LLExe
  {
    theQueue.insertAtTail(value);
  }
    
  public T dequeue()
  {
    return theQueue.removeAtHead();
  }

  public static void main(String args[])
  {
    Queue<String> q = new Queue<String>();

    q.enqueue("Fred");
    q.enqueue("Barney");
    q.enqueue("Wilma");
    q.enqueue("Betty");

    while (!q.isEmpty())
    {
      System.out.println(q.dequeue());
    }
  }
 
}