  import java.util.Scanner;
import java.util.StringTokenizer; 
public class main {

	public static void main(String[] args) {
		  Queue<String> A = new Queue<String>();
		  Stack<String> B = new Stack<String>();
		  Scanner scan = new Scanner(System.in);
		  System.out.println("Enter a equation");
		  String s = scan.nextLine();
		  StringTokenizer st = new StringTokenizer(s);
		  String temp;
		  int i = 0;
		     while (st.hasMoreTokens()) {
		    	
		    	 temp= st.nextToken();
		    	 if(isDouble(temp)){
		    		 A.enqueue(temp);
		    	 }
		    	 else if (temp.equals("(")){
		    		 B.push(temp);
		    	 }
		    	 else if((temp.equals("+") | temp.equals("-") | temp.equals("*") | temp.equals("/"))){
		    		 if(temp.equals("+") | temp.equals("-") | B.isEmpty()){
		    			 B.push(temp);
		    		 }
		    		 else{
		    			 while(!B.isEmpty() && B.peek() != "("){
		    				 A.enqueue(B.pop());
		    			 }
		    			 B.push(temp);
		    		 }
		    	 }
		    	 if(temp.equals(")")){
		    		 while (!B.isEmpty() && B.peek() != '(')
		    		    {
		    		      A.enqueue(B.pop());
		    		    }
		    		    B.pop();
		    		  }
		    		} //end of while
		    	 
		     double answer = 0;
		     String num1;
		     String num2;
		     String oper;
		     while (!A.isEmpty()){
		    	 
		     oper = A.dequeue(); // pops the operator
		     if(oper.equalsIgnoreCase("+")){
		     	num2 = A.dequeue(); // pops num2
		     	num1 = A.dequeue(); // pops num1
		     	double d1 = Double.parseDouble(num1); // converts string to double
		     	double d2 = Double.parseDouble(num2);
		     	answer = d1 + d2;
		     	A.enqueue(Double.toString(answer)); // pushes number
		     }
		     else if(oper.equalsIgnoreCase("-")){
		    	 num2 = A.dequeue(); // pops num2
			     	num1 = A.dequeue(); // pops num1
			     	double d1 = Double.parseDouble(num1); // converts string to double
			     	double d2 = Double.parseDouble(num2);
			     	answer = d1 - d2;
			     	A.enqueue(Double.toString(answer)); // pushes number
		     } else if(oper.equalsIgnoreCase("*")){
		    	 num2 = A.dequeue(); // pops num2
			     	num1 = A.dequeue(); // pops num1
			     	double d1 = Double.parseDouble(num1); // converts string to double
			     	double d2 = Double.parseDouble(num2);
			     	answer = d1 * d2;
			     	A.enqueue(Double.toString(answer)); // pushes number
			    
		     }
		     else if(oper.equalsIgnoreCase("/")){
		    	 num2 = A.dequeue(); // pops num2
			     	num1 = A.dequeue(); // pops num1
			     	double d1 = Double.parseDouble(num1); // converts string to double
			     	double d2 = Double.parseDouble(num2);
			     	answer = d1 / d2;
			     	A.enqueue(Double.toString(answer)); // pushes number
			    
		     }

		     }
	
	}
		     
	


	
	
	

public static boolean isDouble(String s) {
    boolean isValidInteger = false;
    try
    {
       Double.parseDouble(s);

       // s is a valid integer

       isValidInteger = true;
    }
    catch (NumberFormatException ex)
    {
       // s is not an integer
    }

    return isValidInteger;
 }
}
