public class LLExe extends RuntimeException
{
  public LLExe(String s)
  {
    super(s);
  }
}