public class BSTException extends Exception
{
  public BSTException(String s)
  {
    super(s);
  }
}
