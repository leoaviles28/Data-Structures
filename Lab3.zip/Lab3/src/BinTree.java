import java.util.Random;

public class BinTree<T>
{
  private Node<T> root;
  private Random r;

  public BinTree()
  {
    this.root = null;
    this.r = new Random();
  }

  public void makeRandomTree(int n)
  {
    for (int i = 0; i < n; i++)
    {
      ranInsert(i);
    }
  }

  public void ranInsert(int name)
  {
    Node<T> where = root;
    Node<T> next = null;
    boolean done = (where == null);
    if (root == null)
    {
      root = new Node<T>(name);
      return;
    }
    while (!done)
    {
      if (r.nextBoolean())
      {
        next = where.getLeft();
        if (next == null)
        {
          where.setLeft(new Node<T>(name));
          done = true;
        }
      }
      else
      {
        next = where.getRight();
        if (next == null)
        {
          where.setRight(new Node<T>(name));        
          done = true; 
        }
      }
      where = next;
    }
  }

    
  public String toString()
  {
    return toString(this.root, "", 0);
  }

  private String toString(Node<T> r, String soFar, int depth)
  {
    String retval = soFar;
    if (r == null)
    {
      retval += "Null\n";
    }
    else
    {
      retval += r.getName() + "\n";
      retval = toString(r.getLeft(), retval, depth + 1);
      retval = toString(r.getRight(), retval, depth + 1);
    }
    return retval;
  }

  public class Node<R>
  {
    private R value;
    private Node<R> left;
    private Node<R> right;
    private int name;

    public Node(int n, R val, Node<R> lft, Node<R> r)
    {
      this.name = n;
      this.value = val;
      this.left = lft;
      this.right = r;
    }

    public Node (int n, R val)
    {
      this(n, val, null, null);
    }

    public Node (int n)
    {
      this(n, null, null, null);
    }

    public Node ()
    {
      this(0, null, null, null);
    }

    public R getValue()
    {
      return this.value;
    }

    public int getName()
    {
      return this.name;
    }

    public Node<R> getLeft()
    {
      return this.left;
    }
  
    public Node<R> getRight()
    {
      return this.right;
    }

    public void setLeft(Node<R> lft)
    {
      this.left = lft;
    }

    public void setRight(Node<R> r)
    {
      this.right = r;
    }
  }

  public static void main(String args[])
  {
    BinTree<Integer> bt = new BinTree<Integer>();

    bt.makeRandomTree(Integer.parseInt(args[0]));
    System.out.println(bt);
  }
}
        
    