import java.util.Random;

public class BST<T extends Comparable<T>> 
{
  private Node<T> root;

  public BST()
  {
    this.root = null;
  }

  public void insert(T datum) throws BSTException
  {
    this.root = insert(this.root, datum);
  }

  private Node<T> insert(Node<T> r, T datum) throws BSTException
  {
    if( r == null)
    {
      return new Node<T>(datum);
    }
    else
    {
      int sign = r.getData().compareTo(datum);
      if(sign == 0)
      {
        throw new BSTException("Duplicate Entry " + datum);
      }
      else if(sign > 0)
      {
        r.setLeft(insert(r.getLeft(), datum));
      }
      else
      {
        r.setRight(insert(r.getRight(), datum));
      }
      return r;
    }
  }

  public T lookup(T target)
  {
    Node<T> where = root;
    T retval = null;

    while (where != null && retval == null)
    {
      int sign = where.getData().compareTo(target);
      if (sign == 0)
        retval = where.getData();
      else if(sign > 0)
        where = where.getLeft();
      else
        where = where.getRight();
    }
    return retval;
  }
 
  public T delete(T target)
  {
	  root = delete(root, target);
	  return target;
  }
  
  private Node<T> delete(Node<T> p, T toDelete)
  {
     if (p == null)  throw new RuntimeException("cannot delete.");
     else
     if (compare(toDelete, p.data) < 0)
     p.left = delete (p.left, toDelete);
     else
     if (compare(toDelete, p.data)  > 0)
     p.right = delete (p.right, toDelete);
     else
     {
        if (p.left == null) return p.right;
        else
        if (p.right == null) return p.left;
        else
        {
        // get data from the rightmost node in the left subtree
           p.data = retrieveData(p.left);
        // delete the rightmost node in the left subtree
           p.left =  delete(p.left, p.data) ;
        }
     }
     return p;
  }
  private T retrieveData(Node<T> p)
  {
     while (p.right != null) p = p.right;

     return p.data;
  }

  public String toString()
  {
    String retval = "";
    return toString(root, retval);
  }

  public String toString(Node<T> r, String retval)
  {
    if (r == null)
    {
      return retval + "null" + "\n";
    }
    else
    {
      retval += r.getData() + "\n";
      retval = toString(r.getLeft(), retval);
      retval = toString(r.getRight(), retval);
    }
    return retval;
  }

  public static void main(String args[]) throws BSTException
  {
    BST<Integer> ibst = new BST<Integer>();
//inserts 100 random numbers into binary search tree
    int i = 0;
    int newRand;
    while(i<100){
    	Random generator = new Random();
         newRand = generator.nextInt();
    	ibst.insert(newRand);	
    	i++;
    }
  
    
    System.out.println(ibst);
    //System.out.println(ibst.lookup(60));
    //System.out.println(ibst.lookup(25));
   
    BST<String> sbst = new BST<String>();
    sbst.insert("beetle");
    sbst.insert("catapult");
    sbst.insert("dog");
    sbst.insert("wombat");
    sbst.insert("horse");
    sbst.insert("cat");
    sbst.insert("horseradish");
    sbst.insert("caterwaul");
    sbst.insert("cow");
    sbst.insert("sloth");
    System.out.println(sbst);
  }
}
