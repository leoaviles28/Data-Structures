import java.util.Scanner;

public class Lab1 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Hello welcome to exponents with recurcison"); //Ask user for base and exponent
		System.out.println("Please enter the base");
		 double base=(scanner.nextDouble());
		 System.out.println("Please enter the exponent");
		 int exponent=(scanner.nextInt());
		 
		 double answerwhile = exponentSolvedWhile(base,exponent); //using while loop
		 double answer = exponentSolved(base,exponent); //using rec
		 System.out.println("Your answer is " + answer); // tells user answer using rec
		 System.out.println("Your answer is " + answerwhile); // tells user answer using while
	}

static int  countRec = 0; //count rec 
static int countNonrec = 0;//count non rec
	
public static double exponentSolvedWhile(double base,int exponent){ //function using while for exponents
	int count=0;
	double retvalue;

	double inf = Double.POSITIVE_INFINITY;
	
	if(base == 0)			{ // if base equals 0 and exponent is less then 0 return inf
		if(exponent < 0){
			return inf;
						}
		if(exponent <= 0){ // if exponent is greater then 0 return zero
			return 0;
		}
		
							}
	
	if(exponent == 0){ // if exponent is 0 return 1
		return retvalue = 1.0;
					}
	
	if(exponent == 1){ //if exponent is 1 return base
		return base;
	}
	
	int sign; // use to signal if pos(0) or neg(1)
	if(exponent < 0){ // checks to see if sign of exponent is positive or negative
		sign = 1;
		exponent = exponent * -1;
	}
	else sign = 0;
	
	double answer = 1;
	while(exponent > 0){ // does the computation
		answer = answer *base;
		exponent--;
		count++;
	}
	System.out.println("Count using while loop " + count);
	if(sign == 1) return 1/answer; //divides 1.answer to get neg exponent answer
	else return answer;
	}
	



public static double exponentSolved(double base, int exponent){ // using recurs
	double retvalue;

	double inf = Double.POSITIVE_INFINITY;
	
	if(base == 0)			{
		if(exponent < 0){
			return inf;
						}
		if(exponent <= 0){
			return 0;
		}
		
							}
	
	if(exponent == 0){
		return retvalue = 1.0;
					}
	
	if(exponent == 1){
		return base;
	}
	
	int sign;
	if(exponent < 0){
		sign = 1;
		exponent = exponent * -1;
	}
	else sign = 0;
	
	
	 if(exponent <= 0){
		 double answer = base;
		 return answer;
	 }
	 else{
		 countRec++;
		 exponent--;
		 double answer = exponentSolved(base,exponent) * base; //using recur solves exponents
	if(sign == 1) {
		System.out.println("Total number of for recur is " + countRec);
		return 1/answer;
	}
	else{
		System.out.println("Total number of for recur is " + countRec);
		 return answer;
	 }
	 }
}
}