//This is a java program to perform all permutation of given list of numbers of a specific length
import java.util.Scanner;
 
public class Per 
{
	//This method will find the permutations of n numbers
   public static <T> void permute(int[] a, int k) throws BSTException 
    {

        if (k == a.length) 
        {
        BST<Integer> ibst = new BST<Integer>();
            for (int i = 0; i < a.length; i++) 
            {
            	ibst.insert(a[i]);
                System.out.print(" [" + a[i] + "] ");
          
            }
            System.out.println();
            System.out.println();
            int depthBST = ibst.maxDepthBST(null); 
            System.out.println("The depth is " + depthBST);
            System.out.println(ibst);
            
        } 
        else 
        {
            for (int i = k; i < a.length; i++) 
            {
                int temp = a[k];
                a[k] = a[i];
                a[i] = temp;
 
                permute(a, k + 1);
 
                temp = a[k];
                a[k] = a[i];
                a[i] = temp;
            }
        }
	
    }
 
   


	public static void main(String args[]) throws BSTException 
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the length of list: ");
        int N = in.nextInt();
        int[] input = new int[N];
 
        for (int i = 0; i < N; i++)
            input[i] = i;
 

        
        System.out.println("The original sequence is: ");
        for (int i = 0; i < N; i++)
            System.out.print(input[i] + " ");
 
        System.out.println("\nThe permuted sequences are: ");
        permute(input, 0);
 
    }
}