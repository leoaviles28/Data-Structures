import java.util.Random;

public class BST<T extends Comparable<T>> 
{
  private Node<T> root;

  public BST()
  {
    this.root = null;
  }

  public void insert(T datum) throws BSTException
  {
    this.root = insert(this.root, datum);
  }

  private Node<T> insert(Node<T> r, T datum) throws BSTException
  {
    if( r == null)
    {
      return new Node<T>(datum);
    }
    else
    {
      int sign = r.getData().compareTo(datum);
      if(sign == 0)
      {
        throw new BSTException("Duplicate Entry " + datum);
      }
      else if(sign > 0)
      {
        r.setLeft(insert(r.getLeft(), datum));
      }
      else
      {
        r.setRight(insert(r.getRight(), datum));
      }
      return r;
    }
  }

  public T lookup(T target)
  {
    Node<T> where = root;
    T retval = null;

    while (where != null && retval == null)
    {
      int sign = where.getData().compareTo(target);
      if (sign == 0)
        retval = where.getData();
      else if(sign > 0)
        where = where.getLeft();
      else
        where = where.getRight();
    }
    return retval;
  }
 
  public void delete()
  {
	  
  }
 
  public int maxDepthBST(T ibst) {
		Node<T> where = root;
		int retval=maxDepth(where);
		return retval;
	}

  public int maxDepth(Node root) {
	    if(root==null)
	        return 0;
	 
	    int leftDepth = maxDepth(root.left);
	    int rightDepth = maxDepth(root.right);
	 
	    int bigger = Math.max(leftDepth, rightDepth);
	 
	    return bigger+1;
	}
  
  
  
  private T retrieveData(Node<T> p)
  {
     while (p.right != null) p = p.right;

     return p.data;
  }

  public String toString()
  {
    String retval = "";
    return toString(root, retval);
  }

  public String toString(Node<T> r, String retval)
  {
    if (r == null)
    {
      return retval + "null" + "\n";
    }
    else
    {
      retval += r.getData() + "\n";
      retval = toString(r.getLeft(), retval);
      retval = toString(r.getRight(), retval);
    }
    return retval;
  }

  public static void main(String args[]) throws BSTException
  {
    BST<Integer> ibst = new BST<Integer>();
//inserts 100 random numbers into binary search tree
    int i = 0;
    int newRand;
    while(i<100){
    	Random generator = new Random();
         newRand = generator.nextInt();
    	ibst.insert(newRand);	
    	i++;
    }
  
    
    System.out.println(ibst);

   
 
  }
}
