public class LL<T>
{
  ListElement<T> head, tail;
  int size;

  public LL()
  {
    this.head = new ListElement<T>();
    this.tail = head;
    this.size = 0;
  }

  public boolean isEmpty()
  {
    return this.size == 0;
  }

  public void insertAtHead(T p)
  {
    this.head.setLink(new ListElement<T>(p, head.getLink()));
    this.size++;
    if (this.tail == this.head)
      this.tail = head.getLink();
  }
  
  public T removeAtHead()
  {
    T retval = null;
    if (this.isEmpty())
      throw new LLException("Empty List");
    else
    {
      retval = this.head.getLink().getValue();
      this.head.setLink(this.head.getLink().getLink());
      if (this.head.getLink() == null)
        this.tail = this.head;
      size--;
    }
    return retval;
  }

  public void insertAtTail(T p)
  {
    tail.setLink(new ListElement<T>(p, tail.getLink()));
    size++;
    tail = tail.getLink();
  }

  public int getSize()
  {
    return this.size;
  }

  public String toString()
  {
    String retval = "";
    if (this.isEmpty())
      retval = "Empty List";
    else
    {
      ListElement<T> where = head.getLink();
      while (where != null)
      {
        retval += where.getValue() + "\n";
        where = where.getLink();
      }
    }
    return retval;    
  }

  public void printMe()
  {
    printMe(head.getLink());
  }

  public void printMe(ListElement<T> h)
  {
    if (h == null)
      System.out.println();
    else
    {
      System.out.println(h.getValue());
      printMe(h.getLink());
    }
  }

  public static void main(String args[])
  {
    LL<Double> myLL = new LL<Double>();

    myLL.insertAtTail(3.14);
    myLL.insertAtTail(5.0);
    myLL.insertAtTail(6.0);
    myLL.insertAtTail(7.0);

    myLL.printMe();

    LL<Double> newLL;
    newLL = myLL;
    newLL.insertAtTail(100.0);

    System.out.println(myLL);
  }


  public class ListElement<R>
  {
      private R value;
      private ListElement<R> link;
    
      public ListElement(R v, ListElement<R> le)
      {
        this.value = v;
        this.link = le;
      }
    
      public ListElement(R v)
      {
        this(v, null);
      }
    
      public ListElement()
      {
        this(null, null);
      }
    
      public void setValue(R p)
      {
        this.value = p;
      }
    
      public R getValue()
      {
        return this.value;
      }
    
      public ListElement<R> getLink()
      {
        return this.link;
      }
    
      public void setLink(ListElement<R> lnk)
      {
        this.link = lnk;
      }

      public String toString()
      {
        return "\nListElement: value = " + this.value + " link = " + this.link + "\n";
      }
    }
  }  