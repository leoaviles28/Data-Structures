import java.util.Scanner;
public class Stack<T>
{
  public LL<T> theStack;

  public Stack()
  {
    theStack = new LL<T>();
  }

  public boolean isEmpty()
  {
    return theStack.isEmpty();
  }

  public boolean isFull()
  {
    return false;
  }

  public void push(T value) throws LLException
  {
    theStack.insertAtHead(value);
  }
    
  public T pop()
  {
    return theStack.removeAtHead();
  }
  

public static boolean isNumeric(String str)  // method will check if the string is a number
{  
try  
{  
  double d = Double.parseDouble(str);  
}  
catch(NumberFormatException nfe)  
{  
  return false;  
}  
return true;  
}

  public static void main(String args[])
  {
    Stack<String> s = new Stack<String>();
    Scanner scanner = new Scanner(System.in);
    int repeat = 0 ;
    while (repeat < 1){
    	
    
    String sign;
    String number1;
    String number;

int i = 0;
int w = 0;


while(w<2){
System.out.println("Enter number"); // Ask user for number
number = scanner.nextLine();

if(!isNumeric(number)){ // Checks to see if string is a number if not will continue to ask user for number
while(!isNumeric(number)){
	System.out.println("Enter number");
	 number = scanner.nextLine();
							}
		s.push(number); // pushes number
		w++;
						}
else{
	s.push(number);
	w++; //controls loop to repeat twice for 2 numbers
}
}

int signnum=0;
  
while(signnum < 1){ // checks to see what string is in terms of sign
    		 System.out.println("Enter operation"); //ask user for sign
    		 sign = scanner.nextLine();
    		 	if(sign.equalsIgnoreCase("+")){
    		 s.push(sign);
    		 signnum++;
    		 	}
    		 	else if(sign.equalsIgnoreCase("-")){
    	    		 s.push(sign);
    	    		 signnum++;
    	    		 	}
    	    			  
    		 	else if(sign.equalsIgnoreCase("*")){
    	    		 s.push(sign);
    	    		 signnum++;
    	    		 	}
    	    			  
    		 	else if(sign.equalsIgnoreCase("/")){
    	    		 s.push(sign);
    	    		 signnum++;
    	    		 	}
}		  
    			  
    		 
    			 

    	

double answer = 0;
String num1;
String num2;
String oper;

oper = s.pop(); // pops the operator
if(oper.equalsIgnoreCase("+")){
	num2 = s.pop(); // pops num2
	num1 = s.pop(); // pops num1
	double d1 = Double.parseDouble(num1); // converts string to double
	double d2 = Double.parseDouble(num2);
	answer = d1 + d2;
	s.push(Double.toString(answer)); // pushes number
}
else if(oper.equalsIgnoreCase("-")){
	num2 = s.pop();
	num1 = s.pop();
	double d1 = Double.parseDouble(num1);
	double d2 = Double.parseDouble(num2);
	answer = d1 - d2;
	s.push(Double.toString(answer));
} else if(oper.equalsIgnoreCase("*")){
	num2 = s.pop();
	num1 = s.pop();
	double d1 = Double.parseDouble(num1);
	double d2 = Double.parseDouble(num2);
	answer = d1 * d2;
	s.push(Double.toString(answer));
}
else if(oper.equalsIgnoreCase("/")){
	num2 = s.pop();
	num1 = s.pop();
	double d1 = Double.parseDouble(num1);
	double d2 = Double.parseDouble(num2);
	answer = d1 / d2;
	s.push(Double.toString(answer));
}


System.out.println("Your answer is " + s.pop()); //displays answer
System.out.println("Would you like to do another operation? Y/N"); //ask user if they would like to repeat operation
String anotherone = scanner.nextLine();
 	if(anotherone.equalsIgnoreCase("N")){
 		repeat++;
 	}
    
  }
}
}

 