public class LLException extends RuntimeException
{
  public LLException(String s)
  {
    super(s);
  }
}