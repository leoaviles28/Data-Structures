import java.util.Hashtable;
import java.util.Scanner;
import java.util.Enumeration;

public class Lab5 {
 
 public static void main(String[] args) {
	 Scanner in = new Scanner(System.in);
   Enumeration names;
   Enumeration dumhas;
   Integer key;
   
   // Creating a Hashtable
   Hashtable<Integer, String> hashtable = 
              new Hashtable<Integer, String>();
   Hashtable<Integer, String> testhash = 
           new Hashtable<Integer, String>();
  
   System.out.println("Enter the number of words you want to enter ");
   int num = in.nextInt();
   int numberofkeys = 0;
   int loop =0;
   while(loop<num){
	   System.out.println("Enter a key value: ");
	   int num1 = in.nextInt();
	   
	   
	   System.out.println("Enter a word ");
	   String line = in.next();
	   testhash.put(num1,line);
	   hashtable.put(num1,line);
	   loop++;
   }

while(!in.equals("no")){
	 System.out.println("What would you like to do with the list?");
	 System.out.println("RESEQUENCE,LIST,ADD_MORE, OR no to exit");
	 String line = in.next();
	 String value;
	 
	 if(line.equals("RESEQUENCE")){
		 dumhas = testhash.keys();
		 names = hashtable.keys();
		 while(dumhas.hasMoreElements()) {
			      key = (Integer) dumhas.nextElement();
			     numberofkeys++;
			   }
		
		 int increment=10;
		increment= numberofkeys * increment;
		
		System.out.println();
		
		 while(names.hasMoreElements()) {
		      key = (Integer) names.nextElement();
		      value = hashtable.get(key);
		      hashtable.put(increment,value);
		      
		      increment=increment-10;
		      hashtable.remove(key);
		   }
		
	 }
	 
	 
	 if(line.equals("LIST")){
		 names = hashtable.keys();
		   while(names.hasMoreElements()) {
			      key = (Integer) names.nextElement();
			      System.out.println("Key: " +key+ " & Value: " + hashtable.get(key));
			   }
	 }
	 
	 
	 if(line.equals("ADD_MORE")){
		  System.out.println("Enter a key value: ");
		   int num1 = in.nextInt();
		   
		   System.out.println("Enter a word ");
		   String line2 = in.next();
		   names = hashtable.keys();
		   hashtable.put(num1,line2);
		   testhash.put(num1,line2);
	 }
}
 }
}